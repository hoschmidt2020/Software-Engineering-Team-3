# Software-Engineering-Team-3-Gradle
 The Gradle build implementation of our project
